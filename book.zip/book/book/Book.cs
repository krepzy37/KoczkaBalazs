﻿namespace book;

internal class Book
{
    public string ISBN { get; private set; }
    public List<Author> Authors { get; private set; }
    public string Title { get; private set; }
    public int Year { get; private set; }
    public string Language { get; private set; }
    public int Stock { get; set; }
    public int Price { get; private set; }

    public Book(string isbn, string title, int year, string language, int price, int stock, params string[] authorNames)
    {
        if (isbn.Length != 10 || !isbn.All(char.IsDigit))
            throw new ArgumentException("Az ISBN 10 számjegyű szám lehet.");

        if (authorNames.Length < 1 || authorNames.Length > 3)
            throw new ArgumentException("Egy könyvnek 1-3 szerzője lehet.");

        if (title.Length < 3 || title.Length > 64)
            throw new ArgumentException("A címnek 3 és 64 karakter között kell lennie.");

        if (year < 2007 || year > DateTime.Now.Year)
            throw new ArgumentException("Az évnek 2007 és a jelenlegi év között kell lennie.");

        if (!new[] { "angol", "német", "magyar" }.Contains(language))
            throw new ArgumentException("A nyelv csak angol/magyar/német lehet.");

        if (price < 1000 || price > 10000 || price % 100 != 0)
            throw new ArgumentException("Az ár 1000 és 10000 között lehet (kerek 100-as).");
        ISBN = isbn;
        Title = title;
        Year = year;
        Language = language;
        Price = price;
        Stock = stock;
        Authors = authorNames.Select(name => new Author(name)).ToList();
    }

    public Book(string title, string authorName)
    {
        ISBN = GenerateRandomISBN();
        Title = title;
        Year = 2024;
        Language = "magyar";
        Price = 4500;
        Stock = 0;
        Authors = new List<Author> { new Author(authorName) };
    }

    private static string GenerateRandomISBN()
    {
        var random = new Random();
        return string.Join("", Enumerable.Range(0, 10).Select(_ => random.Next(0, 10)));
    }

    public override string ToString()
    {
        string authorsLabel = Authors.Count == 1 ? "Szerző:" : "Szerzők:";
        string stockInfo = Stock > 0 ? $"{Stock} db" : "Beszerzés alatt";

        return $"{authorsLabel} {string.Join(", ", Authors)}\nCím: {Title}\nKiadás éve: {Year}\nNyelv: {Language}\nKészlet: {stockInfo}\nÁr: {Price} Ft";
    }
}