﻿
namespace book;

internal class Author
{
    public string FirstName { get; private set; }
    public string LastName { get; private set; }
    public Guid Id { get; private set; }

    public Author(string fullName)
    {
        string[] parts = fullName.Split(' ');
        if (parts.Length != 2 || parts.Any(p => p.Length < 3 || p.Length > 32))
            throw new ArgumentException("Full name must consist of a first and last name, each between 3 and 32 characters.");

        FirstName = parts[0];
        LastName = parts[1];
        Id = Guid.NewGuid();
    }

    public override string ToString() => $"{FirstName} {LastName}";
}


