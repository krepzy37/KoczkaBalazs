﻿using book;

List<Book> books = GenerateBooks(15);

int initialStock = books.Sum(b => b.Stock);

int totalRevenue = 0;
int booksOutOfStock = 0;

Random random = new Random();

for (int i = 0; i < 100; i++)
{
    if (books.Count == 0) break;

    Book book = books[random.Next(books.Count)];

    if (book.Stock > 0)
    {
        book.Stock--;
        totalRevenue += book.Price;
    }
    else
    {
        if (random.NextDouble() < 0.5)
        {
            book.Stock += random.Next(1, 11);
        }
        else
        {
            books.Remove(book);
            booksOutOfStock++;
        }
    }
}

int finalStock = books.Sum(b => b.Stock);
int stockDifference = finalStock - initialStock;

Console.WriteLine($"Bruttó bevétel: {totalRevenue} Ft");
Console.WriteLine($"Nagykerből kifogyott könyvek: {booksOutOfStock}");
Console.WriteLine($"Kezdeti raktárkészlet: {initialStock} db");
Console.WriteLine($"Jelenlegi raktárkészlet: {finalStock} db");
Console.WriteLine($"Készletváltozás: {stockDifference} db\n");
        

static List<Book> GenerateBooks(int count)
{
    Random random = new Random();
    List<Book> books = new List<Book>();
    HashSet<string> usedIsbns = new HashSet<string>();

    string[] titlesHu = {
    "Safi'Jiiva Ostrom",
    "Az ősi erdő",
    "Minden vadász Álma 3",
    "Az utolsó fehér lovag",
    "Fejbe kell ütni kalapáccsal",
    "A sárkány titkai",
    "A hófödte csúcsok",
    "A fák között",
    "Az elszakadt híd",
    "A fekete mágus utolsó küzdelme",
    "A titokzatos völgy",
    "A kincsek őrzői",
    "A tűz hegyén",
    "A tenger sötét mélye",
    "Az arany hajnal"
};

    string[] titlesEn = {
    "Safi'Jiiva Siege",
    "The Ancient Forest",
    "Every Hunter's Dream III",
    "The Last White Knight",
    "Bonk them in the head with a hammer",
    "The Secrets of the Dragon",
    "The Snow-Capped Peaks",
    "Among the Trees",
    "The Broken Bridge",
    "The Black Mage's Final Battle",
    "The Mysterious Valley",
    "The Guardians of the Treasure",
    "On the Fire Mountain",
    "The Dark Depths of the Sea",
    "The Golden Dawn"
};


    string[] authors = { "John Monsterhunterworldiceborne", "Erdőjáró Elemér", "Nightshade Paolumu", "Frostfang Barioth", "Peter Hammermain", "Kalapátsos Ferenc", "Vizi Adrián", "Azz Admirális" };

    while (books.Count < count)
    {
        string isbn;
        do
        {
            isbn = GenerateRandomISBN();
        } while (usedIsbns.Contains(isbn));

        usedIsbns.Add(isbn);

        string language = random.NextDouble() < 0.8 ? "magyar" : "angol";
        string title = language == "magyar" ? titlesHu[random.Next(titlesHu.Length)] : titlesEn[random.Next(titlesEn.Length)];
        int year = random.Next(2007, DateTime.Now.Year + 1);
        int price = random.Next(10, 101) * 100;
        int stock = random.NextDouble() < 0.3 ? 0 : random.Next(5, 11);

        int authorCount = random.NextDouble() < 0.7 ? 1 : random.Next(2, 4);
        string[] selectedAuthors = authors.OrderBy(_ => random.Next()).Take(authorCount).ToArray();

        books.Add(new Book(isbn, title, year, language, price, stock, selectedAuthors));
    }

    return books;
}

static string GenerateRandomISBN()
{
    Random random = new Random();
    return string.Join("", Enumerable.Range(0, 10).Select(_ => random.Next(0, 10)));
}

/*Console.WriteLine("Késleten lévő kiválasztott könyvek:");
foreach (var book in books)
{
    Console.WriteLine($"\n\t{book.ToString()}");
    
}*/
    
